speed-dating_raw.csv - Original dataset
Speed_Dating_Clean_SMOTE.csv - Dataset after cleaning, feature engineering and SMOTE
Speed_Dating_Clean_SMOTE_train.csv - Training dataset derived from Speed_Dating_Clean_SMOTE.csv
Speed_Dating_Clean_SMOTE_test.csv - Testing dataset derived from Speed_Dating_Clean_SMOTE.csv
Final Analysis.ipynb - A compilation of our analysis with proper documentation: Data cleaning, feature engineering, data exploration, SMOTE, Jupyter analysis, and Darwin analysis
Final Analysis.html - A copy of our codes, ran with outputs